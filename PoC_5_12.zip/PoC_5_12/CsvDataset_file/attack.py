import tensorflow as tf
class SimpleLinearModel(tf.Module):
    def __init__(self):
        self.a = tf.Variable(3.0)
        self.b = tf.Variable(2.0)
        self.logdir = './tmp/importevent_log'  # 指定日志目录
        self.file_writer = tf.summary.create_file_writer(self.logdir)
        

    @tf.function
    def __call__(self, x):
        dataset = tf.data.experimental.CsvDataset(
          "./tmp/tmpcsv.csv",
          [tf.float32,  # Required field, use dtype or empty tensor
          tf.constant([0.0], dtype=tf.float32),  # Optional field, default to 0.0
          tf.int32,  # Required field, use dtype or empty tensor
          ],
          select_cols=[0,1,2]
        )
        
        iterable = iter(dataset)
        tf.print(next(iterable))
        # Only parse last three columns
        ## 能够读取csv文件，并且能够读取任意字符串处理，窃取文件内容，且支持相对路径。
# 保存模型
        return self.a * x + self.b

# 实例化模型
model = SimpleLinearModel()       
result = model(tf.constant(5.0))

save_dir = 'model/csvdataset/saved_model'
tf.saved_model.save(model, save_dir)


'''
tf.raw_ops.CSVDatasetV2
tf.raw_ops.CSVDataset
tf.data.experimental.CsvDataset
tf.compat.v1.data.experimental.CsvDataset
tf.raw_ops.ExperimentalCSVDataset

/tensorflow/core/kernels/data/experimental/csv_dataset_op.cc
38
```json
{
  "user controlled input": {
    "filenames": "filenames_tensor",
    "compression_type": "compression_type",
    "record_defaults": "record_defaults_list",
    "select_cols": "select_cols_tensor",
    "exclude_cols": "exclude_cols_tensor",
    "buffer_size": "buffer_size",
    "field_delim": "delim",
    "header": "header",
    "use_quote_delim": "use_quote_delim",
    "na_value": "na_value"
  },
  "behavior": "pure mathematical calculation, read and write files",
  "Possible abuse": "Potential",
  "Description of abuse": "An attacker could exploit user-controlled inputs to perform actions such as: (1) Buffer size manipulation could lead to resource exhaustion. (2) Selecting excessive amounts or specific patterns of filenames could cause unauthorized reading of files if file access control is not properly configured. Additionally, manipulating the delimiters and compression type could inject or distort data processing logic.",
  "Impacts": [
    "DoS: Resource Consumption (Memory)",
    "Read Files or Directories",
    "Modify Files or Directories",
    "Unexpected State",
    "Quality Degradation"
  ]
}
```
'''
