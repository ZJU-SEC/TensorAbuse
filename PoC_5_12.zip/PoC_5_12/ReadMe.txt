本文件夹包含共 16 个 PoC，其中各个 PoC 的含义、能力、种类、可否被 ModelScan 检测等都已经被收录到 PoC_05_11.xlsx 里。

每个文件夹都至少包含以下文件：
    attack.py   恶意 model 的训练代码
    model.py    触发当前文件夹恶意 model 的代码

部分文件夹包含以下文件：
    server.py   泄漏 ip 类的 PoC 在训练、触发时都需要事先运行的 python 代码，确保恶意 server 端能正常地为恶意 model 服务
    server_for_train.py     部分泄漏 ip 类 / GetShell 等 PoC 在训练 model 和触发 model 时所需的 server 代码不同，训练恶意 model 时需要事先运行 server_for_train.py
    server_for_hack.py      部分泄漏 ip 类 / GetShell 等 PoC 在训练 model 和触发 model 时所需的 server 代码不同，触发恶意 model 时需要事先运行 server_for_train.py