import tensorflow as tf
from tensorflow.python.ops.gen_experimental_dataset_ops import register_dataset, register_dataset_v2


dispatcher = tf.data.experimental.service.DispatchServer(config=tf.data.experimental.service.DispatcherConfig(port=1235))
print("config = ", dispatcher._config)
dispatcher_address = dispatcher.target.split("://")[1]
worker = tf.data.experimental.service.WorkerServer(
    tf.data.experimental.service.WorkerConfig(
        dispatcher_address=dispatcher_address))
print("dispatcher.target = ", dispatcher.target, type(dispatcher.target))
print("wait for link to 10.214.148.18:1235 ...")

while True:
    a = 1