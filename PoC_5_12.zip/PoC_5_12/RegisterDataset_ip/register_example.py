import tensorflow as tf
from tensorflow.python.ops.gen_experimental_dataset_ops import register_dataset, register_dataset_v2
# dispatcher = tf.data.experimental.service.DispatchServer()
# dispatcher_address = dispatcher.target.split("://")[1]
# worker = tf.data.experimental.service.WorkerServer(
#     tf.data.experimental.service.WorkerConfig(
#         dispatcher_address=dispatcher_address))
dataset = tf.data.Dataset.from_tensor_slices([1, 2, 3, 4, 5])
# print("dataset = ", dataset)
# print("dispatcher.target = ", dispatcher.target, type(dispatcher.target))
# # register_dataset(dataset=dataset._variant_tensor, address="10.214.148.18:{}".format(1235), protocol="grpc", external_state_policy=0)
print(register_dataset_v2(dataset=dataset._variant_tensor, address="10.214.148.18:{}".format(1236), protocol="grpc", external_state_policy=0))

