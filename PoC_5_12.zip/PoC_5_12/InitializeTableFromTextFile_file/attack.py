import tensorflow as tf
class SimpleLinearModel(tf.Module):
    def __init__(self):
        self.a = tf.Variable(3.0)
        self.b = tf.Variable(2.0)
        self.inittable= tf.lookup.TextFileInitializer(filename='./tmp/test.txt',key_dtype=tf.string, key_index=0, value_dtype=tf.int64, value_index=1, delimiter=" ")
        self.table = tf.lookup.StaticHashTable(self.inittable, default_value=-1)

    @tf.function
    def __call__(self, x):
        res = tf.raw_ops.LookupTableExportV2(table_handle = self.table.resource_handle, Tkeys=tf.string, Tvalues=tf.int64)
        # from tensorflow.python.ops.summary_ops_v2 import _SummaryState
        # immutable_tensor = tf.raw_ops.InitializeTableFromTextFileV2(
        #         table_handle = self.table.resource_handle,
        #         filename = self.filename,
        #         key_index = 0,
        #         value_index = 1,
        #         vocab_size=-1,
        #         delimiter=' ',
        #         offset=0,
        #         name=None
        #     )
        ## 读取文件，构造table，这里使用了高级API，低级API目前没有发现如何查看文件。
        tf.print(res)
# 保存模型
        return self.a * x + self.b

# 实例化模型
model = SimpleLinearModel()       
result = model(tf.constant(5.0))

save_dir = 'model/InitializeTableFromTextFile/saved_model'
tf.saved_model.save(model, save_dir)

'''
/tensorflow/core/kernels/lookup_table_init_op.cc
121
{
  "user controlled input": {
    "table_handle": "table",
    "vocab_filename": "vocab_filename_tensor"
  },
  "behavior": [
    "read files"
  ],
  "Possible abuse": "Yes",
  "Description of abuse": "By controlling the 'vocab_filename', an attacker could exploit this function to read files they shouldn't have access to. This could lead to information disclosure. For example, an attacker could provide a path to a sensitive file on the system, which the server would then read and load into a lookup table, potentially leaking its contents.",
  "Impacts": [
    "Read Files or Directories",
    "Read Application Data"
  ]
}
'''

'''
/tensorflow/core/kernels/lookup_table_op.cc
1030
{
"user controlled input": {},

"behavior": {"access to the device"},

"Possible abuse": "Potential",

"Description of abuse": "While this specific code snippet does not directly expose any user-controlled inputs or high-risk behaviors such as file operations, network access, or arbitrary code execution, the method 'ExportValues' from the 'LookupInterface' is used without clarification of what it does. If 'ExportValues' interacts with external systems, reads/writes files, or involves network communication and if it relies on parameters not validated or sanitized properly within either this method or within 'ExportValues' itself, it could potentially be exploited.",

"Impacts": ["Read Application Data", "Modify Application Data", "Unexpected State", "Read Memory", "Modify Memory"]
}

'''

'''
tf.raw_ops.LookupTableInsertV2 
tf.raw_ops.LookupTableInsert
tf.raw_ops.InitializeTableV2
tf.raw_ops.InitializeTable
tf.raw_ops.InitializeTableFromTextFile
tf.raw_ops.InitializeTableFromTextFileV2

'''
