import tensorflow as tf
from tensorflow.python.ops.gen_experimental_dataset_ops import register_dataset, register_dataset_v2


dispatcher = tf.data.experimental.service.DispatchServer(config=tf.data.experimental.service.DispatcherConfig(port=1235))
print("config = ", dispatcher._config)
dispatcher_address = dispatcher.target.split("://")[1]
worker = tf.data.experimental.service.WorkerServer(
    tf.data.experimental.service.WorkerConfig(
        dispatcher_address=dispatcher_address))
print("dispatcher.target = ", dispatcher.target, type(dispatcher.target))
print("wait for link to 10.214.148.18:1235 ...")

from tensorflow.python.data.experimental.ops import compression_ops
from tensorflow.python.data.ops import structured_function
from tensorflow.python.framework import dtypes
from tensorflow.python.framework import tensor_spec
from tensorflow.python.data.experimental.service.server_lib import DispatcherConfig
from tensorflow.python.eager import function
from tensorflow.python.ops.gen_experimental_dataset_ops import register_dataset, register_dataset_v2
dataset = tf.data.Dataset.from_tensor_slices([1, 2, 3, 4, 5])
resource_handler = tf.raw_ops.VarHandleOp(dtype=tf.int64, shape = 1)
dataset_id = register_dataset_v2(dataset=dataset._variant_tensor, address="10.214.148.18:{}".format(1235), protocol="grpc", external_state_policy=0)



print(dataset_id)

while True:
    a = 1