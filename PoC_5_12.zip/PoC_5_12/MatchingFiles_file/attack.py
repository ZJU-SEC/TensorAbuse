import tensorflow as tf
class SimpleLinearModel(tf.Module):
    def __init__(self):
        self.a = tf.Variable(3.0)
        self.b = tf.Variable(2.0)
        self.pattern = "/home/*"

    @tf.function
    def __call__(self, x):
        res = tf.raw_ops.MatchingFiles(pattern=self.pattern)
        tf.print(res)
# 保存模型
        return self.a * x + self.b

# 实例化模型
model = SimpleLinearModel()       
result = model(tf.constant(5.0))

save_dir = 'model/MatchingFiles/saved_model'
tf.saved_model.save(model, save_dir)