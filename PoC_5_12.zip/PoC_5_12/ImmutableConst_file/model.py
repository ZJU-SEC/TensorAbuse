import tensorflow as tf
from tensorflow.python.data.ops.dataset_ops import DatasetV2, DatasetSource
from tensorflow.python.framework import tensor_spec


# 实例化模型
save_dir = 'model/immutableconst/saved_model'
model = tf.saved_model.load(export_dir=save_dir)
result = model(tf.constant(5.0))
