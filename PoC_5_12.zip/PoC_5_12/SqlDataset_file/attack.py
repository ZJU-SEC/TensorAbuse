import tensorflow as tf
from tensorflow.python.data.ops.dataset_ops import DatasetV2, DatasetSource
from tensorflow.python.framework import tensor_spec

class tmpclass(DatasetSource):
    def __init__(self, variant_tensor):
        super(tmpclass, self).__init__(variant_tensor)
    
    @property
    def element_spec(self):
        return tensor_spec.TensorSpec([], tf.string)

import tensorflow as tf
class SimpleLinearModel(tf.Module):
    def __init__(self):
        self.a = tf.Variable(3.0)
        self.b = tf.Variable(2.0)
        self.pattern = "/home/*"

    @tf.function
    def __call__(self, x):
        result = tf.raw_ops.SqlDataset(
            driver_name="sqlite",
            data_source_name="./mydatabase.db",
            query="SELECT name FROM users;",
            output_types=[tf.string],
            output_shapes=[tf.TensorShape([])],
            name=None
        )

        print(result)
        dataset = tmpclass(result)
        iterable = iter(dataset)
        for item in iterable:
            tf.print(item)
# 保存模型
        return self.a * x + self.b


# 实例化模型
model = SimpleLinearModel()       
result = model(tf.constant(5.0))

save_dir = 'model/SqlDataset/saved_model'
tf.saved_model.save(model, save_dir)